<?php

namespace Ambab\DashboardLanding\Plugin;

class CreatePostPlugin
{
    /**
     * Change redirect after signUp to custom dashboard page.
     *
     * @param \Magento\Framework\Controller\Result\Redirect $result
     */
    public function afterExecute(
        \Magento\Customer\Controller\Account\CreatePost $subject,
        $result)
    {
        $result->setPath('dashboardlanding/customer'); // Change this to what you want
        return $result;
    }
}
