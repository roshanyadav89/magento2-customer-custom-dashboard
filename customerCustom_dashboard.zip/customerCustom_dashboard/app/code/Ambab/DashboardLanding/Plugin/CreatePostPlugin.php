<?php

namespace Ambab\DashboardLanding\Plugin;

class CreatePostPlugin
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->context = $context;
    }

    /**
     * Change redirect after signUp to custom dashboard page.
     *
     * @param \Magento\Framework\Controller\Result\Redirect $result
     */
    public function afterExecute(
        \Magento\Customer\Controller\Account\CreatePost $subject,
        $result)
    {
        return $this->context->getResultRedirectFactory()->create()->setPath('dashboardlanding/customer'); // Change this to what you want
        //return $result;
    }
}
