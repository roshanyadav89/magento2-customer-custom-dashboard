<?php

namespace Ambab\DashboardLanding\Plugin;

class LoginPostPlugin
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->context = $context;
    }

    /**
     * Change redirect after login to custom dashboard page.
     *
     * @param \Magento\Framework\Controller\Result\Redirect $result
     */
    public function afterExecute(
        \Magento\Customer\Controller\Account\LoginPost $subject,
        $result)
    {
        return $this->context->getResultRedirectFactory()->create()->setPath('dashboardlanding/customer'); // Change this to what you want
        //return $result;
    }
}
