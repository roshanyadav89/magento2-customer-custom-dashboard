<?php

namespace Ambab\DashboardLanding\Plugin;

class LoginPostPlugin
{
    /**
     * Change redirect after login to custom dashboard page.
     *
     * @param \Magento\Framework\Controller\Result\Redirect $result
     */
    public function afterExecute(
        \Magento\Customer\Controller\Account\LoginPost $subject,
        $result)
    {
        $result->setPath('dashboardlanding/customer'); // Change this to what you want
        return $result;
    }
}
